See the root README for setup. Set OPENAI_API_KEY in a local .env file. Never commit .env.
