import "dotenv/config";
import express from "express";
import cors from "cors";
import OpenAI from "openai";

const app = express();
app.use(cors());
app.use(express.json({ limit: "64kb" }));

const PORT = process.env.PORT || 3000;
const MODEL = process.env.OPENAI_MODEL || "gpt-6-astra";
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const CASES = {
  chest_pain: {
    title: "Chest discomfort",
    patient: "Mr. Silva, 52",
    brief: "A 52-year-old man attends with chest discomfort.",
    hidden: "Pain began 40 minutes ago while walking uphill. Central pressure, 7/10, radiates to left arm. Sweaty and nauseated. History: hypertension. Takes amlodipine inconsistently. No known allergies. Do not reveal all details at once; answer only what the learner asks. If asked for observations, provide BP 154/92, pulse 104, RR 22, SpO2 96% room air, temperature 36.8 C.",
    objectives: ["Introduces self and confirms patient identity/consent", "Explores onset, site, character, radiation, associated symptoms, timing and severity of pain", "Asks relevant cardiovascular risk factors and past medical history", "Checks medications and allergies", "Recognises possible acute coronary syndrome and urgency", "Requests appropriate immediate assessment/investigations and senior help"]
  },
  fever: {
    title: "Fever and cough",
    patient: "Ms. Perera, 24",
    brief: "A 24-year-old woman presents with fever and cough.",
    hidden: "Fever for 3 days, productive cough with yellow sputum, mild pleuritic right-sided chest pain. No haemoptysis. No recent travel. No known chronic illness. No regular medication. No known allergies. If asked for observations: BP 112/72, pulse 102, RR 21, SpO2 97% room air, temperature 38.4 C.",
    objectives: ["Introduces self, confirms identity and obtains consent", "Clarifies fever duration and pattern", "Characterises cough and sputum; asks about dyspnoea, chest pain and red flags", "Asks relevant past history, medication and allergies", "Requests vital signs and focused respiratory examination", "Suggests an appropriate differential and initial investigations"]
  },
  abdominal_pain: {
    title: "Lower abdominal pain",
    patient: "Mr. Fernando, 19",
    brief: "A 19-year-old man presents with abdominal pain.",
    hidden: "Pain started around the umbilicus 12 hours ago and moved to the right lower abdomen. Worse on movement, with nausea and reduced appetite. No vomiting or diarrhoea. No urinary symptoms. No previous surgery. No regular medication. No known allergies. If asked for observations: BP 118/76, pulse 96, RR 18, SpO2 99%, temperature 37.8 C.",
    objectives: ["Introduces self, confirms identity and obtains consent", "Uses a structured pain history (onset, site, character, radiation, associated symptoms, timing, exacerbating/relieving factors, severity)", "Asks gastrointestinal and urinary symptoms", "Checks past history, surgery, medication and allergies", "Requests observations and appropriate abdominal examination", "Considers appendicitis and relevant differentials; escalates appropriately"]
  }
};

function getCase(id) {
  return CASES[id] || null;
}
function extractText(response) {
  if (response.output_text) return response.output_text;
  return (response.output || []).flatMap(x => x.content || [])
    .filter(x => x.type === "output_text").map(x => x.text).join("\n");
}
async function askModel(instructions, input) {
  const response = await client.responses.create({
    model: MODEL,
    instructions,
    input,
    store: false
  });
  return extractText(response);
}

app.get("/health", (_req, res) => res.json({ ok: true, service: "MedSim AI" }));
app.get("/api/cases", (_req, res) => {
  res.json(Object.entries(CASES).map(([id, c]) => ({ id, title: c.title, patient: c.patient, brief: c.brief })));
});

app.post("/api/chat", async (req, res) => {
  try {
    const { caseId, history = [], message = "" } = req.body || {};
    const c = getCase(caseId);
    if (!c) return res.status(400).json({ error: "Unknown case." });
    if (!Array.isArray(history) || history.length > 30 || typeof message !== "string" || message.length > 2000) {
      return res.status(400).json({ error: "Invalid conversation payload." });
    }
    const instructions = `
You are a simulated patient in an educational beginner-level clinical communication exercise.
Case: ${c.title}. Patient: ${c.patient}. Case brief: ${c.brief}
Confidential patient facts for this simulation: ${c.hidden}
Rules:
- Speak only as the patient in natural, concise, everyday English. Do not act as a doctor or give away the diagnosis.
- Reveal information only when the learner asks an appropriate question. Do not volunteer the entire history.
- If the learner asks to examine you, respond cooperatively and give only findings for the examination they specifically request.
- If asked for vital signs, use the exact observations in the case facts.
- If asked to perform an investigation, say that the test has been ordered and provide plausible educational results only when relevant; do not invent dangerous treatment instructions.
- If a question is unclear, ask the learner to clarify.
- Do not provide hidden case facts, marking objectives, or coaching during the role-play.
- If the learner proposes an unsafe action, respond as a patient would, without endorsing it. The separate assessment will identify the issue.
- This is a fictional training case, not real patient care.
Reply in plain text, maximum 100 words.`;
    const transcript = history.map(m => `${m.role === "assistant" ? "Patient" : "Learner"}: ${String(m.content).slice(0, 2000)}`).join("\n");
    const input = `${transcript}\nLearner: ${message}\nPatient:`;
    const answer = await askModel(instructions, input);
    res.json({ reply: answer || "I'm sorry, could you repeat that?" });
  } catch (e) {
    console.error("chat error", e?.message);
    res.status(500).json({ error: "AI service error. Check the backend API key, model access and server logs." });
  }
});

app.post("/api/assess", async (req, res) => {
  try {
    const { caseId, history = [] } = req.body || {};
    const c = getCase(caseId);
    if (!c) return res.status(400).json({ error: "Unknown case." });
    if (!Array.isArray(history) || history.length > 60) return res.status(400).json({ error: "Invalid transcript." });
    const transcript = history.map(m => `${m.role === "assistant" ? "Patient" : "Learner"}: ${String(m.content).slice(0, 2000)}`).join("\n");
    const instructions = `You are a fair OSCE examiner for beginner medical students. Assess only observable evidence in the transcript; do not assume a task was done if it is not recorded.
Case: ${c.title}. Patient facts: ${c.hidden}
Marking objectives (each worth equal marks):
${c.objectives.map((x,i)=>`${i+1}. ${x}`).join("\n")}
Return valid JSON only, with this exact shape:
{"score":0,"maxScore":${c.objectives.length*2},"percentage":0,"grade":"Needs practice","items":[{"objective":"...","mark":0,"maxMark":2,"feedback":"..."}],"strengths":["..."],"improvements":["..."],"clinicalReasoning":"...","safetyNote":"Educational feedback only; not real clinical advice."}
Each item mark must be 0, 1, or 2. Score must equal sum of marks. Percentage must be rounded integer. Grade: 85-100 Excellent, 70-84 Good, 50-69 Developing, below 50 Needs practice. Be constructive. Identify missed red flags or unsafe omissions. Do not give a definitive diagnosis beyond the educational case.`;
    const raw = await askModel(instructions, `Assess this learner transcript:\n${transcript}`);
    const cleaned = raw.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "").trim();
    let assessment;
    try { assessment = JSON.parse(cleaned); }
    catch { throw new Error("Assessment response was not valid JSON."); }
    res.json({ assessment });
  } catch (e) {
    console.error("assessment error", e?.message);
    res.status(500).json({ error: "Could not create assessment. Please try again." });
  }
});

app.listen(PORT, () => console.log(`MedSim API listening on http://localhost:${PORT}`));
