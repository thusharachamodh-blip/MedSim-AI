# MedSim AI — Android clinical role-play starter

An educational beginner-level Android app with:
- AI patient role-play through text
- Android speech recognition (voice input)
- Android TextToSpeech (spoken AI patient)
- Three beginner cases
- End-of-case OSCE-style feedback and scoring
- Node.js backend that keeps the OpenAI API key off the phone

## Important limitations
This is a learning simulator, not a medical device or a source of real-patient care. Cases and feedback are educational and may be inaccurate. A qualified clinical educator should review scenarios and marking rubrics before formal teaching use. Never enter identifiable patient information.

The Android project has not been compiled or tested on a physical device in this environment. Open it in Android Studio, sync Gradle, then run it on an emulator or Android phone.

## Architecture
- `android/`: Kotlin + Jetpack Compose app
- `backend/`: Node.js + Express API
- The app sends chat turns to your backend.
- The backend calls the OpenAI Responses API.

## Requirements
- Android Studio (recent stable version)
- Android SDK 35
- JDK 17
- Node.js 20+
- An OpenAI API project/key with API billing enabled

## 1. Start the backend
In a terminal:
```bash
cd backend
cp .env.example .env
```
Edit `.env` and set `OPENAI_API_KEY`. You may change `OPENAI_MODEL` to a model available to your API project.

Then:
```bash
npm install
npm start
```
The backend listens on port 3000.

For Android Emulator, the app's default backend URL is:
`http://10.0.2.2:3000/`

For a physical Android phone, replace it in `android/app/build.gradle.kts` with your computer's LAN IP, e.g. `http://192.168.1.10:3000/`. Phone and computer must be on the same Wi-Fi. Do not expose this development HTTP server to the public internet.

## 2. Open the Android app
Open the `android` folder in Android Studio. Wait for Gradle sync, then run the `app` configuration.

If Android Studio prompts you to install SDK 35 or accept licenses, follow its prompts.

## 3. Test
1. Start the backend.
2. Run the Android app.
3. Choose a case, then tap Start.
4. Ask the patient questions using text or the microphone.
5. Tap Finish Case to receive the OSCE assessment.

## 4. API key safety
Never put your OpenAI API key in Android source code, `local.properties`, BuildConfig, or the APK. Keep it only in the backend `.env` file (which is gitignored). For production, deploy the backend behind HTTPS, add authentication, per-user rate limits, request limits, and monitoring.

## 5. Voice behaviour
Voice input uses Android's installed speech-recognition service and requires microphone permission. AI patient speech uses Android TextToSpeech and requires an installed English voice. Availability varies by device and language pack.

## 6. Clinical safety
The app is for supervised learning only. It does not diagnose real people, prescribe treatment, or replace clinical guidelines, local protocols, supervision, or emergency services. For real emergencies, use local emergency pathways rather than this app.
