package com.medsim.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

data class CaseInfo(val id: String, val title: String, val patient: String, val brief: String)
data class ChatMessage(val role: String, val content: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MedSimApp() }
    }
}

private class MedSimApi {
    private val http = OkHttpClient()
    private val base = BuildConfig.API_BASE_URL
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    suspend fun cases(): List<CaseInfo> = withContext(Dispatchers.IO) {
        val req = Request.Builder().url("${base}api/cases").get().build()
        http.newCall(req).execute().use { response ->
            if (!response.isSuccessful) error("Server error ${response.code}")
            val arr = JSONArray(response.body?.string() ?: "[]")
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                CaseInfo(o.getString("id"), o.getString("title"), o.getString("patient"), o.getString("brief"))
            }
        }
    }

    suspend fun chat(caseId: String, history: List<ChatMessage>, message: String): String =
        withContext(Dispatchers.IO) {
            val h = JSONArray()
            history.forEach { h.put(JSONObject().put("role", it.role).put("content", it.content)) }
            val payload = JSONObject().put("caseId", caseId).put("history", h).put("message", message)
            val req = Request.Builder().url("${base}api/chat")
                .post(payload.toString().toRequestBody(jsonType)).build()
            http.newCall(req).execute().use { response ->
                val body = JSONObject(response.body?.string() ?: "{}")
                if (!response.isSuccessful) error(body.optString("error", "Server error"))
                body.getString("reply")
            }
        }

    suspend fun assess(caseId: String, history: List<ChatMessage>): JSONObject =
        withContext(Dispatchers.IO) {
            val h = JSONArray()
            history.forEach { h.put(JSONObject().put("role", it.role).put("content", it.content)) }
            val payload = JSONObject().put("caseId", caseId).put("history", h)
            val req = Request.Builder().url("${base}api/assess")
                .post(payload.toString().toRequestBody(jsonType)).build()
            http.newCall(req).execute().use { response ->
                val body = JSONObject(response.body?.string() ?: "{}")
                if (!response.isSuccessful) error(body.optString("error", "Assessment failed"))
                body.getJSONObject("assessment")
            }
        }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedSimApp() {
    val api = remember { MedSimApi() }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var cases by remember { mutableStateOf<List<CaseInfo>>(emptyList()) }
    var selected by remember { mutableStateOf<CaseInfo?>(null) }
    var messages by remember { mutableStateOf(listOf<ChatMessage>()) }
    var draft by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var assessment by remember { mutableStateOf<JSONObject?>(null) }
    var ttsReady by remember { mutableStateOf(false) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }

    DisposableEffect(Unit) {
        val engine = TextToSpeech(context) { status -> ttsReady = status == TextToSpeech.SUCCESS }
        tts = engine
        onDispose { engine.stop(); engine.shutdown() }
    }

    fun speak(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "patient_reply")
    }

    LaunchedEffect(Unit) {
        try { cases = api.cases() } catch (e: Exception) { error = "Cannot reach backend: ${e.message}" }
    }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) draft = spoken
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.ENGLISH.toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your question to the patient")
            }
            try { speechLauncher.launch(intent) } catch (_: Exception) { error = "Speech recognition is unavailable on this device." }
        } else error = "Microphone permission is required for voice input."
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF126B65), secondary = Color(0xFF426A85))) {
        Scaffold(topBar = {
            TopAppBar(title = {
                Column {
                    Text("MedSim AI", fontWeight = FontWeight.Bold)
                    Text("Beginner clinical practice", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            })
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (selected == null) {
                    Text("Choose a patient case", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Practise history-taking, communication and clinical reasoning.")
                    if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
                    if (cases.isEmpty()) {
                        CircularProgressIndicator()
                        Text("Loading cases. Make sure the backend is running.")
                    }
                    cases.forEach { c ->
                        ElevatedCard(onClick = { selected = c; messages = emptyList(); assessment = null; error = "" }, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text(c.title, fontWeight = FontWeight.Bold)
                                Text(c.patient, color = MaterialTheme.colorScheme.primary)
                                Text(c.brief, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    Text("Educational simulation only — not for real patient care.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    val c = selected!!
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(c.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                            Text(c.patient, color = MaterialTheme.colorScheme.primary)
                        }
                        TextButton(onClick = { selected = null; messages = emptyList(); assessment = null; error = "" }) { Text("Cases") }
                    }
                    if (messages.isEmpty() && assessment == null) {
                        ElevatedCard {
                            Column(Modifier.padding(14.dp)) {
                                Text("Your task", fontWeight = FontWeight.Bold)
                                Text(c.brief)
                                Text("Introduce yourself, obtain consent, and take a focused history. Ask for examination findings or observations when needed.", style = MaterialTheme.typography.bodySmall)
                                Button(onClick = {
                                    loading = true
                                    scope.launch {
                                        try {
                                            val first = api.chat(c.id, emptyList(), "Please begin the consultation by greeting me as the patient and explaining why you came.")
                                            messages = listOf(ChatMessage("assistant", first))
                                            speak(first)
                                        } catch (e: Exception) { error = e.message ?: "Could not start case" }
                                        loading = false
                                    }
                                }, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
                                    Text(if (loading) "Starting..." else "Start consultation")
                                }
                            }
                        }
                    }
                    if (assessment != null) {
                        AssessmentView(assessment!!)
                        Button(onClick = { selected = null; messages = emptyList(); assessment = null }, modifier = Modifier.fillMaxWidth()) { Text("Choose another case") }
                    } else {
                        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(messages) { m ->
                                val patient = m.role == "assistant"
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (patient) Arrangement.Start else Arrangement.End) {
                                    Surface(
                                        color = if (patient) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.primaryContainer,
                                        shape = RoundedCornerShape(16.dp),
                                        modifier = Modifier.widthIn(max = 310.dp)
                                    ) {
                                        Column(Modifier.padding(12.dp)) {
                                            Text(if (patient) "PATIENT" else "YOU", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            Text(m.content)
                                            if (patient) TextButton(onClick = { speak(m.content) }) { Text("Speak") }
                                        }
                                    }
                                }
                            }
                            if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
                        }
                        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(
                                value = draft, onValueChange = { draft = it }, modifier = Modifier.weight(1f),
                                placeholder = { Text("Ask the patient...") }, maxLines = 3,
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                                keyboardActions = KeyboardActions(onSend = {
                                    val q = draft.trim()
                                    if (q.isNotEmpty() && !loading) {
                                        draft = ""; val old = messages
                                        messages = old + ChatMessage("user", q); loading = true; error = ""
                                        scope.launch {
                                            try { val reply = api.chat(c.id, old, q); messages = messages + ChatMessage("assistant", reply); speak(reply) }
                                            catch (e: Exception) { error = e.message ?: "Request failed" }
                                            loading = false
                                        }
                                    }
                                })
                            )
                            IconButton(onClick = {
                                if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.ENGLISH.toLanguageTag())
                                    }
                                    try { speechLauncher.launch(intent) } catch (_: Exception) { error = "Speech recognition unavailable" }
                                } else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                            }) { Icon(Icons.Default.Mic, contentDescription = "Speak question") }
                            IconButton(enabled = draft.isNotBlank() && !loading, onClick = {
                                val q = draft.trim(); draft = ""; val old = messages
                                messages = old + ChatMessage("user", q); loading = true; error = ""
                                scope.launch {
                                    try { val reply = api.chat(c.id, old, q); messages = messages + ChatMessage("assistant", reply); speak(reply) }
                                    catch (e: Exception) { error = e.message ?: "Request failed" }
                                    loading = false
                                }
                            }) { Icon(Icons.Default.Send, contentDescription = "Send") }
                        }
                        OutlinedButton(
                            enabled = messages.isNotEmpty() && !loading,
                            onClick = {
                                loading = true; error = ""
                                scope.launch {
                                    try { assessment = api.assess(c.id, messages) }
                                    catch (e: Exception) { error = e.message ?: "Assessment failed" }
                                    loading = false
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Icon(Icons.Default.Stop, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("Finish case & assess") }
                    }
                    Text("Training only. Do not use this simulation to make decisions for real patients.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun AssessmentView(data: JSONObject) {
    val items = data.optJSONArray("items") ?: JSONArray()
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("OSCE assessment", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("${data.optInt("score")} / ${data.optInt("maxScore")}  •  ${data.optInt("percentage")}%  •  ${data.optString("grade")}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        Text("Marking breakdown", fontWeight = FontWeight.Bold)
        for (i in 0 until items.length()) {
            val item = items.getJSONObject(i)
            ElevatedCard {
                Column(Modifier.padding(12.dp)) {
                    Text("${item.optInt("mark")}/${item.optInt("maxMark")} — ${item.optString("objective")}", fontWeight = FontWeight.Bold)
                    Text(item.optString("feedback"))
                }
            }
        }
        Text("Strengths", fontWeight = FontWeight.Bold)
        BulletArray(data.optJSONArray("strengths"))
        Text("Areas to improve", fontWeight = FontWeight.Bold)
        BulletArray(data.optJSONArray("improvements"))
        Text("Clinical reasoning feedback", fontWeight = FontWeight.Bold)
        Text(data.optString("clinicalReasoning"))
        Text(data.optString("safetyNote"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun BulletArray(arr: JSONArray?) {
    if (arr == null) return
    for (i in 0 until arr.length()) Text("• ${arr.optString(i)}")
}
